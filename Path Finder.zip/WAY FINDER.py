"""

Created on Wed Jun 30 09:38:51 2021

@author: Ananda Rao(cse), 201801330011

"""
# Libraries needed for this project to work

import imageio as img # pip install imageio
import matplotlib.pyplot as plt # pip install matplotlib
import numpy as np # pip install numpy

# Warehouse Layout (image reading from the local system)

image = img.imread('img.png')

# Initializing the locations

locations = {'A': 0,
             'B': 1,
             'C': 2,
             'D': 3,
             'E': 4,
             'F': 5,
             'G': 6,
             'H': 7,
             'I': 8,
             'J': 9,
             'K': 10,
             'L': 11,
             'M': 12,
             'N': 13,
             'O': 14,
             'P': 15,
             'Q': 16,
             'R': 17,
             'S': 18,
             'T': 19}

# Defining the places

actions = [0,1,2,3,4,5,
           6,7,8,9,10,11,
           12,13,14,15,16,
           17,18,19]

# Defining the constants

gamma = 0.75
alpha = 0.9

# Initializing the inputs 

R = np.array([[0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
              [0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
              [0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
              [0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0],
              [1,0,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0],
              [0,1,0,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0],
              [0,0,0,0,0,1,0,1,0,0,1,0,0,0,0,0,0,0,0,0],
              [0,0,0,1,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0],
              [1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
              [0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0],
              [0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,1,0,0,0,0],
              [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0],
              [0,0,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,0],
              [0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,1,0,1,0],
              [0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0],
              [0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0],
              [0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,1,0,1],
              [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0],
              [0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0],
              [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0]]
            )

# Creating the empty array of 20:20 size 

Q = np.array(np.zeros([20,20]))

for i in range(1000):
  present_possition = np.random.randint(0,20)
  actions_done = []
  for j in range(20):
    if R[present_possition, j] > 0:
      actions_done.append(j)
  next_possition = np.random.choice(actions_done)
  # SD = Temporal Difference
  TD = R[present_possition, next_possition] + gamma*Q[next_possition, np.argmax(Q[next_possition,])] - Q[present_possition, next_possition] 
  Q[present_possition, next_possition] = Q[present_possition, next_possition] + alpha*TD


physical_location = {state: location for location, 
                     state in locations.items()}

# Giving the inputs 

R = np.array([[0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
              [0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
              [0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
              [0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0],
              [1,0,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0],
              [0,1,0,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0],
              [0,0,0,0,0,1,0,1,0,0,1,0,0,0,0,0,0,0,0,0],
              [0,0,0,1,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0],
              [1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
              [0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0],
              [0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,1,0,0,0,0],
              [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0],
              [0,0,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,0],
              [0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,1,0,1,0],
              [0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0],
              [0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0],
              [0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,1,0,1],
              [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0],
              [0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0],
              [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0]]
            )         

# Defining a function

def path(starting_location, ending_location):
    R_new = np.copy(R)
    ending_state = locations[ending_location]
    R_new[ending_state, ending_state] = 1000
    Q = np.array(np.zeros([20,20]))
    for i in range(1000):
        present_possition = np.random.randint(0,20)
        actions_done = []
        for j in range(20):
            if R_new[present_possition, j] > 0:
                actions_done.append(j)
        next_possition = np.random.choice(actions_done)
        # SD = Temporal Difference
        TD = R_new[present_possition, next_possition] + gamma * Q[next_possition, np.argmax(Q[next_possition,])] - Q[present_possition, next_possition]
        Q[present_possition, next_possition] = Q[present_possition, next_possition] + alpha * TD
    path = [starting_location]
    next_location = starting_location
    while (next_location != ending_location):
        starting_state = locations[starting_location]
        next_possition = np.argmax(Q[starting_state,])
        next_location = physical_location[next_possition]
        path.append(next_location)
        starting_location = next_location
    return path

# Defining a function

def long_path(starting_location, intermediate_location, ending_location):
    return path(starting_location, intermediate_location) + path(intermediate_location, ending_location)[1:]

# To show image

plt.figure(5)
plt.imshow(image)
plt.title("WAREHOUSE LAYOUT",color = "orange" )
plt.axis("off")


# For output run the file and type 
# path(starting_location,ending_location)
#                   or
# long_path(starting_lacation,intermediate_location,ending_location)
